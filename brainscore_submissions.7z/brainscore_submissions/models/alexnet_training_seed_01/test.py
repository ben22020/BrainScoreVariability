import pytest
import brainscore_vision


@pytest.mark.travis_slow
def test_has_identifier():
    model = brainscore_vision.load_model('alexnet_training_seed_01')
    assert model.identifier == 'alexnet_training_seed_01'
    